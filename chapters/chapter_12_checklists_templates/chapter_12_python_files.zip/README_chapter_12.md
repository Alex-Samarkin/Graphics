# Chapter 12 Python files

RU:
Файлы главы 12 сгруппированы по подразделам: чек-листы качества, шаблоны скрипта и подписи, автоматический аудит, экспортные требования, peer review, каталог ошибок и итоговая панель готовности.

EN:
Chapter 12 files are grouped by subsections: quality checklists, script/caption templates, automated audit, export requirements, peer review, common mistakes catalog, and master readiness dashboard.

## 12.1. Чек-листы качества рисунка

- `ch12_01_figure_quality_checklist_table.py`
- `ch12_01_checklist_from_dataset.py`

## 12.2. Шаблоны

- `ch12_02_starter_template_generator.py`
- `ch12_02_caption_template_generator.py`

## 12.3. Автоматический аудит рисунка

- `ch12_03_figure_audit_function.py`
- `ch12_03_units_audit.py`

## 12.4. Экспортный чек-лист и требования

- `ch12_04_export_checklist.py`
- `ch12_04_journal_requirements_table.py`

## 12.5. Ревизия и peer review

- `ch12_05_review_before_after.py`
- `ch12_05_peer_review_form.py`

## 12.6. Каталог типичных ошибок

- `ch12_06_common_mistakes_catalog.py`

## 12.7. Итоговая панель готовности

- `ch12_07_master_checklist_dashboard.py`

## Usage

Copy files into:

```text
chapters/chapter_12_checklists_templates/
```

Generate data first:

```powershell
uv run python generate_data.py
```

Run from project root:

```powershell
uv run python chapters/chapter_12_checklists_templates/ch12_01_figure_quality_checklist_table.py
```
