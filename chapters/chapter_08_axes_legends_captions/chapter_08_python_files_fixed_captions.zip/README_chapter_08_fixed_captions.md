# Chapter 08 fixed captions

Fixed files use `fig.tight_layout(rect=[0, bottom, 1, 1])` and place captions inside the visible figure area at `y=0.04`.
